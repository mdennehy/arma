# F3-Folk ARPS Mission-making Template #


## Changes from default F3 ##

* Wolfenswan's function library (ws_fnc) integrated
* Folk ARPS logo.paa file included
* F3 features pre-enabled:
  * Name Tags
  * Automatic Body Removal
  * Safe Start default set to 1 minute
  * Set AI Skill for all factions - Missionmakers can remove the cases they do not need
  * Pre-configured endings 1 -3 with generic titles and texts
* Other changes:
  * Pre-placed a ZEUS player configured to support F3 AI Skill Selector

## Versions ##
* F3 3-3-0
* ws_fnc 20/04/2015
