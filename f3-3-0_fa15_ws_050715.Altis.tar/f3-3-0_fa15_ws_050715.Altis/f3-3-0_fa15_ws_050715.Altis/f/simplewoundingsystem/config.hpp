class woundingsystem
{
	file = "f\simplewoundingsystem";
	class SetDowned {};
	class WoundedEffect{};
	class HasWounded{};
	class EjectWounded{};
	class OnDrag{};
	class LifeTick {};
	class OnDeath {};
	class OnHeal {};
	class OnDamage{};
	class SetBleeding{};
};

